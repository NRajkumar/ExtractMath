﻿using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using Ovml = DocumentFormat.OpenXml.Vml.Office;
using V = DocumentFormat.OpenXml.Vml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConvertEquations;
using MTSDKDN;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Xsl;
using System.Windows.Forms;

namespace MathToText
{
    public class MathtoText
    {
        public static bool doprocess(WordprocessingDocument doc, string docpath, OutPutType Outputype, ref string sError)
        {
            try
            {
                string outfolder = Path.GetDirectoryName(docpath);
                MainDocumentPart mainDoc = doc.MainDocumentPart;
                Document document = mainDoc.Document;
                fnequationprocess(outfolder, Outputype, mainDoc, document);

            }
            catch (Exception ex)
            {
                sError = ex.Message;
                return false;
            }
            return true;
        }


        public static bool doprocess(string docpath, OutPutType Outputype, ref string sError)
        {
           
            try
            {
                using (WordprocessingDocument doc = WordprocessingDocument.Open(docpath, false))
                {
                    string outfolder = Path.GetDirectoryName(docpath);
                    MainDocumentPart mainDoc = doc.MainDocumentPart;
                    Document document = mainDoc.Document;
                    fnequationprocess(outfolder, Outputype, mainDoc, document);
                }
            }
            catch (Exception ex)
            {
                sError = ex.Message;
                return false;
            }
            return true;
        }

        public static bool doprocess(Stream packageStream, string docpath, OutPutType Outputype, ref string sError)
        {
            try
            {
                using (WordprocessingDocument doc = WordprocessingDocument.Open(packageStream, true))
                {
                    string outfolder = Path.GetDirectoryName(docpath);
                    MainDocumentPart mainDoc = doc.MainDocumentPart;
                    Document document = mainDoc.Document;
                    fnequationprocess(outfolder, Outputype, mainDoc, document);
                }
            }
            catch (Exception ex)
            {

                sError = ex.Message;
                return false;
            }
            return true;
        }

        private static void fnequationprocess(string outfolder, OutPutType Outputype, MainDocumentPart mainDoc, Document document)
        {
            string wmfpath = Path.Combine(outfolder, "Eq_1.wmf");
            string binpath = Path.Combine(outfolder, "Eq_1.bin");
            string mathpath = Path.Combine(outfolder, "mml_1.txt");
            string texpath = Path.Combine(outfolder, "tex_1.txt");

            //omath process:
            try
            {
                foreach (var formula in document.Descendants<DocumentFormat.OpenXml.Math.OfficeMath>())
                {
                    string wordDocXml = formula.OuterXml;
                    string stylesheet = AppDomain.CurrentDomain.BaseDirectory.ToString() + "OMML2MML.XSL";
                    XslCompiledTransform xslTransform = new XslCompiledTransform();
                    xslTransform.Load(stylesheet);

                    using (TextReader tr = new StringReader(wordDocXml))
                    {
                        // Load the xml of your main document part.
                        using (XmlReader reader = XmlReader.Create(tr))
                        {
                            using (MemoryStream ms = new MemoryStream())
                            {
                                XmlWriterSettings settings = xslTransform.OutputSettings.Clone();

                                // Configure xml writer to omit xml declaration.
                                settings.ConformanceLevel = ConformanceLevel.Fragment;
                                settings.OmitXmlDeclaration = true;

                                XmlWriter xw = XmlWriter.Create(ms, settings);

                                // Transform our OfficeMathML to MathML.
                                xslTransform.Transform(reader, xw);
                                ms.Seek(0, SeekOrigin.Begin);
                                string sErrMsg = string.Empty;
                                using (StreamReader sr = new StreamReader(ms, Encoding.UTF8))
                                {
                                    string sMathMLContent = sr.ReadToEnd();

                                    sMathMLContent = clsMathMLCleanup.DoMathMLCleanup(sMathMLContent, ref sErrMsg);
                                    File.WriteAllText(mathpath, sMathMLContent);
                                }
                                if (Outputype == OutPutType.MML)
                                {
                                    if (File.Exists(mathpath))
                                    {
                                        string stexContent = File.ReadAllText(mathpath);
                                        //string xmlpattern = @"<w:r xmlns:w=""http://schemas.openxmlformats.org/wordprocessingml/2006/main""><w:rPr><w:rStyle w:val=""MTConvertedEquation"" />< w:t>{0}</w:t></w:r>";
                                        //Run r = new Run(string.Format(xmlpattern, stexContent));

                                        Run r = new Run();
                                        r.RunProperties = new RunProperties();
                                        RunStyle rs = new RunStyle();
                                        rs.Val = "MTConvertedEquation";
                                        r.RunProperties.AppendChild(rs);
                                        Text t = new Text();
                                        t.Text = stexContent;
                                        r.AppendChild(t);
                                        formula.Parent.ReplaceChild(r, formula);

                                    }

                                }
                                else
                                {
                                    if (File.Exists(texpath))
                                        File.Delete(texpath);
                                    fnConvertEqn(Formats.FileTextMathML, Formats.FileTextTeX, MathTypeTranslators.PlainTex, mathpath, true, texpath, ref sErrMsg);

                                    if (File.Exists(texpath))
                                    {
                                        string stexContent = File.ReadAllText(texpath);
                                        stexContent = DoMathTexCleanup(stexContent, ref sErrMsg);
                                        Run r = new Run();
                                        r.RunProperties = new RunProperties();
                                        RunStyle rs = new RunStyle();
                                        rs.Val = "MTConvertedEquation";
                                        r.RunProperties.AppendChild(rs);
                                        Text t = new Text();
                                        t.Text = stexContent;
                                        r.AppendChild(t);
                                        formula.Parent.ReplaceChild(r, formula);
                                    }

                                }

                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
        repetmath:
            try
            {


                var val = document.Descendants<Ovml.OleObject>(); int count = 0;
                foreach (Ovml.OleObject oleObject in val)
                {
                    ++count;

                    // get the oleobject id 
                   
                    if (oleObject.ProgId == "Equation.DSMT4" || oleObject.ProgId == "Equation.3")// in your case, ProgId should be Equation.DSMT4
                    {
                        if (oleObject.ProgId == "Equation.3")
                        {
                            foreach (V.Shape shape in document.Descendants<V.Shape>().Where(x => x.Id.Value == oleObject.ShapeId.Value))
                            {
                                // get the imagedata from relation id 
                                if (shape.Id.Value == oleObject.ShapeId.Value)
                                {

                                    V.ImageData datas = shape.Descendants<V.ImageData>().FirstOrDefault();
                                    var id = datas.RelationshipId;
                                    string embeddingPartString = "/word/embeddings/";
                                    var imagePart = mainDoc.GetPartById(oleObject.Id.Value);

                                    if (imagePart.Uri.ToString().StartsWith(embeddingPartString))
                                    {
                                        string fileName1 = imagePart.Uri.ToString().Remove(0, embeddingPartString.Length);
                                        // Get the stream from the part
                                        System.IO.Stream partStream = imagePart.GetStream(FileMode.Open, FileAccess.Read);

                                        System.IO.FileStream writeStream = new System.IO.FileStream(binpath, FileMode.Create, FileAccess.Write);
                                        ReadWriteStream(partStream, writeStream);
                                        Clipboard.Clear();
                                        using (MemoryStream ms = new MemoryStream())
                                        using (FileStream file = new FileStream(binpath, FileMode.Open, FileAccess.Read))
                                        {
                                            byte[] bytes = new byte[file.Length];
                                            file.Read(bytes, 0, (int)file.Length);
                                            ms.Write(bytes, 0, (int)file.Length);
                                            object obj = ms;
                                            Clipboard.SetData("Embedded Object", obj);
                                            IDataObject ole = Clipboard.GetDataObject();
                                            string[] str = ole.GetFormats();

                                        }
                                        string sErrMsg = string.Empty;
                                        if (File.Exists(mathpath))
                                            File.Delete(mathpath);
                                        fnConvertEqn(Formats.ClipBoardEmbedObject, Formats.FileTextMathML, MathTypeTranslators.MathMl2_NamespaceAttr, "", true, mathpath, ref sErrMsg);

                                        if (File.Exists(mathpath))
                                        {
                                            string sMathMLContent = File.ReadAllText(mathpath);
                                            sMathMLContent = clsMathMLCleanup.DoMathMLCleanup(sMathMLContent, ref sErrMsg);
                                            File.WriteAllText(mathpath, sMathMLContent);
                                        }
                                        if (Outputype == OutPutType.MML)
                                        {
                                            if (File.Exists(mathpath))
                                            {
                                                string stexContent = File.ReadAllText(mathpath);
                                                Text text = new Text();
                                                text.Text = stexContent;
                                                oleObject.Parent.Parent.Append(text);
                                                RunProperties rr = oleObject.Parent.Parent.Descendants<RunProperties>().FirstOrDefault();
                                                RunStyle runStyle = new RunStyle();
                                                runStyle.Val = "MTConvertedEquation";
                                                rr.RunStyle = runStyle;
                                            }

                                        }
                                        else
                                        {
                                            if (File.Exists(texpath))
                                                File.Delete(texpath);
                                            fnConvertEqn(Formats.FileTextMathML, Formats.FileTextTeX, MathTypeTranslators.PlainTex, mathpath, true, texpath, ref sErrMsg);

                                            if (File.Exists(texpath))
                                            {
                                                string stexContent = File.ReadAllText(texpath);
                                                stexContent = DoMathTexCleanup(stexContent, ref sErrMsg);
                                                Text text = new Text();
                                                text.Text = stexContent;
                                                oleObject.Parent.Parent.Append(text);
                                                RunProperties rr = oleObject.Parent.Parent.Descendants<RunProperties>().FirstOrDefault();
                                                RunStyle runStyle = new RunStyle();
                                                runStyle.Val = "MTConvertedEquation";
                                                rr.RunStyle = runStyle;
                                            }

                                        }

                                    }
                                }
                            }
                        }
                        
                        foreach (V.Shape shape in document.Descendants<V.Shape>().OfType<V.Shape>().Where(x => x.Id.Value == oleObject.ShapeId.Value))
                        {
                            // get the imagedata from relation id 

                            if (shape.Id.Value == oleObject.ShapeId.Value)
                            {

                                V.ImageData datas = shape.Descendants<V.ImageData>().FirstOrDefault();
                                var id = datas.RelationshipId;
                                var imagePart = mainDoc.GetPartById(id.Value);
                                Stream data = imagePart.GetStream(FileMode.Open, FileAccess.Read);
                                
                                //export the image    
                                if (File.Exists(wmfpath))
                                    File.Delete(wmfpath);
                                using (Stream file = File.Create(wmfpath))
                                {
                                    CopyStream(data, file);
                                }

                               
                                if (File.Exists(mathpath))
                                    File.Delete(mathpath);
                                string sErrMsg = "";
                                if (oleObject.ProgId == "Equation.3")
                                {
                                   
                                   
                                }
                                else
                                {
                                    fnConvertEqn(Formats.WMF, Formats.FileTextMathML, MathTypeTranslators.MathML2_m_namespace, wmfpath,true, mathpath,  ref sErrMsg);
                                }
                                if (File.Exists(mathpath))
                                {
                                    string sMathMLContent = File.ReadAllText(mathpath);
                                    sMathMLContent = clsMathMLCleanup.DoMathMLCleanup(sMathMLContent, ref sErrMsg);
                                    File.WriteAllText(mathpath, sMathMLContent);
                                }

                                if (Outputype == OutPutType.MML)
                                {
                                    if (File.Exists(mathpath))
                                    {
                                        string stexContent = File.ReadAllText(mathpath);
                                        stexContent = clsMathMLCleanup.DoMathMLCleanup(stexContent, ref sErrMsg);
                                        Run run = oleObject.Parent.Parent.Parent.AppendChild(new Run());
                                        RunProperties runProperties = run.AppendChild(new RunProperties());
                                        runProperties.RunStyle = new RunStyle();
                                        runProperties.RunStyle.Val = "MTConvertedEquation";
                                        run.AppendChild(new Text(stexContent));
                                        oleObject.Parent.Parent.Remove();
                                    }


                                }
                                else
                                {
                                    if (File.Exists(texpath))
                                        File.Delete(texpath);
                                    fnConvertEqn(Formats.FileTextMathML, Formats.FileTextTeX, MathTypeTranslators.PlainTex, mathpath, true, texpath, ref sErrMsg);

                                    if (File.Exists(texpath))
                                    {
                                        string stexContent = File.ReadAllText(texpath);
                                        stexContent = DoMathTexCleanup(stexContent, ref sErrMsg);

                                        Run run = oleObject.Parent.Parent.Parent.AppendChild(new Run());
                                        RunProperties runProperties = run.AppendChild(new RunProperties());
                                        runProperties.RunStyle = new RunStyle();
                                        runProperties.RunStyle.Val = "MTConvertedEquation";
                                        run.AppendChild(new Text(stexContent));
                                        oleObject.Parent.Parent.Remove();

                                    }

                                }
                                //
                            }
                            continue;
                        }
                    }
                }

            }
            catch
            {

            }
            try
            {
                if (document.Descendants<Ovml.OleObject>() != null && document.Descendants<Ovml.OleObject>().OfType<Ovml.OleObject>().Where(x=> x.ProgId == "Equation.DSMT4").Count() > 0)
                    goto repetmath;

            }
            catch (Exception)
            {


            }


            if (File.Exists(wmfpath))
                File.Delete(wmfpath);
            if (File.Exists(mathpath))
                File.Delete(mathpath);
            if (File.Exists(texpath))
                File.Delete(texpath);

            //File.WriteAllText(Path.Combine(outfolder, "fatten.xml"), document.OuterXml.ToString());
        }
        private static void ReadWriteStream(Stream readStream, Stream writeStream)
        {
            int Length = 256;
            Byte[] buffer = new Byte[Length];
            int bytesRead = readStream.Read(buffer, 0, Length);
            // write the required bytes
            while (bytesRead > 0)
            {
                writeStream.Write(buffer, 0, bytesRead);
                bytesRead = readStream.Read(buffer, 0, Length);
            }
            readStream.Close();
            writeStream.Close();
        }
        internal static string DoMathTexCleanup(string sEqnTexFileName, ref string sErrMsg)
        {
            string tmpcnt = sEqnTexFileName;
            try
            {
                sEqnTexFileName = Regex.Replace(sEqnTexFileName, @"^[^\$]*(?=\$)", "", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                sEqnTexFileName = Regex.Replace(sEqnTexFileName, @"(?<=\$)[^\$]*$", "", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                return sEqnTexFileName;
            }
            catch
            {
                return tmpcnt;
            }
        }

        public enum OutPutType
        {
            Tex,
            MML
        }
        public enum Formats
        {
            ClipBoardTextMML,
            ClipBoardTextBase64MTEF,
            ClipBoardEmbedObject,
            WMF,
            GIF,
            EPS,
            FileTextMathML,
            FileTextBase64MTEF,
            FileTextTeX
        }

        public enum MathTypeTranslators
        {
            PlainTex,
            TnFPlainTeX,
            MathML2_m_namespace,
            MathMl2_NamespaceAttr,
            MathML2_NoNamespace,
            AMSTeX,
            AMSLaTeX,
            Texvc,
            None
        }

        internal static EquationInput fnGetInput(Formats format, string sInputFilePath)
        {
            EquationInput inputObject = null;
            switch (format)
            {
                case Formats.ClipBoardTextMML:
                    inputObject = new EquationInputClipboardText(ClipboardFormats.cfMML);
                    break;
                case Formats.ClipBoardTextBase64MTEF:
                    inputObject = new EquationInputClipboardText(ClipboardFormats.cfMML);
                    break;
                case Formats.ClipBoardEmbedObject:
                    inputObject = new EquationInputClipboardEmbeddedObject();
                    break;
                case Formats.WMF:
                    inputObject = new EquationInputFileWMF(sInputFilePath);
                    break;
                case Formats.GIF:
                    inputObject = new EquationInputFileGIF(sInputFilePath);
                    break;
                case Formats.EPS:
                    inputObject = new EquationInputFileEPS(sInputFilePath);
                    break;
                case Formats.FileTextMathML:
                    inputObject = new EquationInputFileText(sInputFilePath, ClipboardFormats.cfMML);
                    break;
                case Formats.FileTextBase64MTEF:
                    inputObject = new EquationInputFileText(sInputFilePath, ClipboardFormats.cfMML);
                    break;
                case Formats.FileTextTeX:
                    inputObject = new EquationInputFileText(sInputFilePath, ClipboardFormats.cfTeX);
                    break;
                default:
                    break;
            }
            return inputObject;
        }

        internal static EquationOutput fnGetOutput(Formats format, string sOutPutFilePath, MathTypeTranslators translator)
        {
            EquationOutput outputObject = null;
            switch (format)
            {
                case Formats.ClipBoardTextMML:
                case Formats.ClipBoardTextBase64MTEF:
                    outputObject = new EquationOutputClipboardText();
                    break;
                case Formats.ClipBoardEmbedObject:
                    throw new Exception("ClipboardEmbedObject cannot be a output type");
                case Formats.WMF:
                    outputObject = new EquationOutputFileWMF(sOutPutFilePath);
                    break;
                case Formats.GIF:
                    outputObject = new EquationOutputFileGIF(sOutPutFilePath);
                    break;
                case Formats.EPS:
                    outputObject = new EquationOutputFileEPS(sOutPutFilePath);
                    break;
                case Formats.FileTextMathML:
                case Formats.FileTextBase64MTEF:
                case Formats.FileTextTeX:
                default:
                    outputObject = new EquationOutputFileText(sOutPutFilePath, translatorNames(translator));
                    break;
            }
            return outputObject;
        }

        internal static string translatorNames(MathTypeTranslators translatorType)
        {
            string sTranslatorName = string.Empty;
            switch (translatorType)
            {
                case MathTypeTranslators.MathML2_m_namespace:
                    sTranslatorName = "MathML2 (m namespace).tdl";
                    break;
                case MathTypeTranslators.PlainTex:
                    sTranslatorName = "Plain TeX.tdl";
                    break;
                case MathTypeTranslators.TnFPlainTeX:
                    sTranslatorName = "T&F-Plain TeX.tdl";
                    break;
                case MathTypeTranslators.AMSTeX:
                    sTranslatorName = "AMSTeX.tdl";
                    break;
                case MathTypeTranslators.AMSLaTeX:
                    sTranslatorName = "AMS LaTeX.tdl";
                    break;
                case MathTypeTranslators.Texvc:
                    sTranslatorName = "Texvc.tdl";
                    break;
                case MathTypeTranslators.MathMl2_NamespaceAttr:
                    sTranslatorName = "MathML2 (namespace attr).tdl";
                    break;
                case MathTypeTranslators.MathML2_NoNamespace:
                    sTranslatorName = "MathML2 (no namespace).tdl";
                    break;
                case MathTypeTranslators.None:
                default:
                    sTranslatorName = "";
                    break;
            }
            return sTranslatorName;
        }

        public static bool fnConvertEqn(Formats inputFormatType, Formats outputFormatType, MathTypeTranslators mathTranslator, string sInputFile, bool bShouldKill, string sOutputFile,ref string sErrMsg)
        {
            try
            {
                if (bShouldKill)
                {
                    System.Diagnostics.Process[] mathProcesses = System.Diagnostics.Process.GetProcessesByName("MathType");
                    if (mathProcesses != null && mathProcesses.Length > 0)
                    {
                        foreach (System.Diagnostics.Process eachProcess in mathProcesses)
                        {
                            eachProcess.Kill();
                        }
                    }
                    System.Threading.Thread.Sleep(100);
                }

                EquationInput input = fnGetInput(inputFormatType, sInputFile);
                EquationOutput output = fnGetOutput(outputFormatType, sOutputFile, mathTranslator);
                ConvertEquation ce = new ConvertEquation();
                if (ce.Convert(input, output))
                    return true;
                else
                {
                    //sErrMsg += ErrorMsg.sErrMsgMTSDK;
                    return false;
                }
                
            }
            catch (Exception ex)
            {
                sErrMsg += ex.ToString();
                return false;
            }
        }
        public static void CopyStream(Stream input, Stream output)
        {
            byte[] buffer = new byte[8 * 1024];
            int len;
            while ((len = input.Read(buffer, 0, buffer.Length)) > 0)
            {
                output.Write(buffer, 0, len);
            }
        }
    }
}
