﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.IO;
using System.Drawing;
using System.Reflection;
using System.Threading;
using System.Diagnostics;
using System.Security.Cryptography;
using System.Data;


//using LogFileError;
namespace System
{
    public static class StringExtension
    {
        public static string TrimStart(this string OriginalSources, string[] TrimStrings)
        {
            string StringChar = OriginalSources;
            try
            {
                foreach (var str in TrimStrings)
                {
                    if (StringChar.StartsWith(str))
                    {
                        foreach (char ch in str.ToCharArray())
                        {
                            StringChar = StringChar.TrimStart(new char[] { ch });
                        }
                    }
                }
            }
            catch { }
            return StringChar;
        }

        public static string TrimEnd(this string OriginalSources, string[] TrimStrings)
        {
            string StringChar = OriginalSources;
            try
            {
                foreach (var str in TrimStrings)
                {
                    if (StringChar.EndsWith(str))
                    {
                        foreach (char ch in str.ToCharArray().Reverse())
                        {
                            StringChar = StringChar.TrimEnd(new char[] { ch });
                        }
                    }
                }
            }
            catch { }
            return StringChar;
        }

        public static string Trim(this string OriginalSources, string[] TrimStrings)
        {
            string StringChar = OriginalSources;
            try
            {
                foreach (var str in TrimStrings)
                {
                    if (StringChar.StartsWith(str))
                    {
                        foreach (char ch in str.ToCharArray())
                        {
                            StringChar = StringChar.TrimStart(new char[] { ch });
                        }
                    }

                    if (StringChar.EndsWith(str))
                    {
                        foreach (char ch in str.ToCharArray().Reverse())
                        {
                            StringChar = StringChar.TrimEnd(new char[] { ch });
                        }
                    }
                }
            }
            catch { }
            return StringChar;
        }

        public static bool Equals(this string OriginalSources, string RegexPattern, RegexOptions RegOpt, bool IsRegex)
        {
            bool IsReturn = false;
            try
            {
                if (IsRegex)
                    IsReturn = Regex.IsMatch(OriginalSources, RegexPattern, RegOpt);
                else
                    IsReturn = OriginalSources.Equals(RegexPattern);
            }
            catch { }
            return IsReturn;
        }
    }
}
namespace mathconverter
{
    public static class clsCommonFunctions
    {
        public static bool bIsInAutomationMode = false;
        public const string iRefBasePath = "\\\\172.16.200.206\\WMS-Data\\27_iCAPS\\01_iRef\\01_TagProcess";
        public static string getCheckSum(string theString)
        {
            string hash;
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                hash = BitConverter.ToString(
                  md5.ComputeHash(Encoding.UTF8.GetBytes(theString))
                ).Replace("-", String.Empty);
            }
            return hash;
        }

        public enum OSTypes
        {
            Windows95,
            Windows98,
            WindowsME,
            WindowsNT3,
            WindowsNT4,
            Windows2000,
            WindowsXP,
            WindowsServer2003,
            WindowsVista,
            Windows7,
            Unknown
        }

        public static OSTypes GetOpertatingSystemName()
        {
            System.OperatingSystem os = System.Environment.OSVersion;
            OSTypes name = OSTypes.Unknown;
            switch (os.Platform)
            {
                case System.PlatformID.Win32Windows:
                    switch (os.Version.Minor)
                    {
                        case 0:
                            name = OSTypes.Windows95;
                            break;
                        case 10:
                            name = OSTypes.Windows98;
                            break;
                        case 90:
                            name = OSTypes.WindowsME;
                            break;
                    }
                    break;
                case System.PlatformID.Win32NT:
                    switch (os.Version.Major)
                    {
                        case 3:
                            name = OSTypes.WindowsNT3;
                            break;
                        case 4:
                            name = OSTypes.WindowsNT4;
                            break;
                        case 5:
                            switch (os.Version.Minor)
                            {
                                case 0:
                                    name = OSTypes.Windows2000;
                                    break;
                                case 1:
                                    name = OSTypes.WindowsXP;
                                    break;
                                case 2:
                                    name = OSTypes.WindowsServer2003;
                                    break;
                            }
                            break;
                        case 6:
                            switch (os.Version.Minor)
                            {
                                case 0:
                                    name = OSTypes.WindowsVista;
                                    break;
                                case 1:
                                    name = OSTypes.Windows7;
                                    break;
                            }
                            break;
                    }
                    break;
            }
            return name;
        }

        public static string AppendToErrorMsg(this string sErrorString, string sErrMsg)
        {
            return sErrorString + Environment.NewLine + sErrMsg + Environment.NewLine;
        }

        public static string AppendToErrorMsg(this string sErrorString, Exception ex)
        {
            //if (Environment.UserName.ToLower().Equals("is3537"))
            return sErrorString + Environment.NewLine + ex.Message + Environment.NewLine + ex.StackTrace;
            //else
            //    return sErrorString + Environment.NewLine + ex.Message;
        }




        static private SizeF MeasureStringSize(string textToMeasure)
        {
            Bitmap bmp = new Bitmap(1, 1);
            Graphics graphics = Graphics.FromImage(bmp);
            using (Font fnt = new Font("Tahoma", 9, FontStyle.Bold))
            {
                SizeF size = graphics.MeasureString(textToMeasure, fnt);
                bmp.Dispose();
                graphics.Dispose();
                return size;
            }
        }

        public static String nz(Object tvalue)
        {
            if (tvalue != null)
            {
                return tvalue.ToString();
            }
            return string.Empty;
        }






        public static int ConvertRomanToArabic(string RomanNumerals)
        {
            int intCalc = 0;
            try
            {
                char[] charRoman = new char[7] { 'I', 'V', 'X', 'L', 'C', 'D', 'M' };
                RomanNumerals = RomanNumerals.ToUpper();
                char[] charThis = RomanNumerals.ToCharArray();
                int[] intThis = new int[charThis.Length];
                bool bValid = false;


                //go through char array to change individual roman numerals to numbers
                for (int i = 0; i < charThis.Length; i++)
                {
                    //check to ensure char array contains only roman numerals
                    foreach (char c in charRoman)
                    {
                        if (charThis[i] == c)
                        {
                            bValid = true;
                            break;
                        }
                    }
                    if (!bValid)
                    {
                        return -1;
                    }

                    switch (charThis[i])
                    {
                        case 'I':
                            intThis[i] = 1;
                            break;
                        case 'V':
                            intThis[i] = 5;
                            break;
                        case 'X':
                            intThis[i] = 10;
                            break;
                        case 'L':
                            intThis[i] = 50;
                            break;
                        case 'C':
                            intThis[i] = 100;
                            break;
                        case 'D':
                            intThis[i] = 500;
                            break;
                        case 'M':
                            intThis[i] = 1000;
                            break;
                    }
                }

                //perform subtraction where needed
                intCalc = 0;
                for (int i = 0; i < intThis.Length - 1; i++)
                {
                    if (intThis[i] < intThis[i + 1])
                    {
                        intCalc = intThis[i + 1] - intThis[i];
                        intThis[i] = intCalc;
                        //two numerals combined into first int, so zero out second int
                        intThis[i + 1] = 0;
                        //avoid doing subtraction twice in a row
                        i++;
                    }
                }

                //add together all of the individual values
                intCalc = 0;
                for (int i = 0; i < intThis.Length; i++)
                {
                    intCalc = intCalc + intThis[i];
                }
            }
            catch { }

            return intCalc;
        }

        public static string ToRoman(int number)
        {
            if ((number < 0) || (number > 3999)) throw new ArgumentOutOfRangeException("insert value betwheen 1 and 3999");
            if (number < 1) return string.Empty;
            if (number >= 1000) return "M" + ToRoman(number - 1000);
            if (number >= 900) return "CM" + ToRoman(number - 900); //EDIT: i've typed 400 instead 900
            if (number >= 500) return "D" + ToRoman(number - 500);
            if (number >= 400) return "CD" + ToRoman(number - 400);
            if (number >= 100) return "C" + ToRoman(number - 100);
            if (number >= 90) return "XC" + ToRoman(number - 90);
            if (number >= 50) return "L" + ToRoman(number - 50);
            if (number >= 40) return "XL" + ToRoman(number - 40);
            if (number >= 10) return "X" + ToRoman(number - 10);
            if (number >= 9) return "IX" + ToRoman(number - 9);
            if (number >= 5) return "V" + ToRoman(number - 5);
            if (number >= 4) return "IV" + ToRoman(number - 4);
            if (number >= 1) return "I" + ToRoman(number - 1);
            throw new ArgumentOutOfRangeException("Input number is Invalid (Arabic To Roman)");
        }









        public static string GetUniqueKey()
        {
            int maxSize = 8;
            char[] chars = new char[62];
            string a;
            a = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            chars = a.ToCharArray();
            int size = maxSize;
            byte[] data = new byte[1];
            System.Security.Cryptography.RNGCryptoServiceProvider crypto = new System.Security.Cryptography.RNGCryptoServiceProvider();
            crypto.GetNonZeroBytes(data);
            size = maxSize;
            data = new byte[size];
            crypto.GetNonZeroBytes(data);
            StringBuilder result = new StringBuilder(size);
            foreach (byte b in data)
            {
                result.Append(chars[b % (chars.Length - 1)]);
            }
            return result.ToString();
        }

        public static bool ExecuteCommand(string FileName, string Arguments, bool bIsWaitForExit)
        {
            try
            {
                System.Diagnostics.Process proc = new System.Diagnostics.Process();
                proc.EnableRaisingEvents = false;
                proc.StartInfo.FileName = FileName;
                proc.StartInfo.Arguments = Arguments;
                proc.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
                //added this line due to error message shown in catch by Prabu 27-03-2015
                // proc.StartInfo.UseShellExecute = false;
                proc.Start();
                if (bIsWaitForExit)
                    proc.WaitForExit();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool ExecuteCommand(string FileName, string Arguments)
        {
            try
            {
                System.Diagnostics.Process proc = new System.Diagnostics.Process();
                proc.EnableRaisingEvents = false;
                proc.StartInfo.FileName = FileName;
                proc.StartInfo.Arguments = Arguments;
                proc.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
                proc.Start();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool OpenFilesinUedit(string FilePath)
        {
            try
            {
                string argsName = ((char)(34)).ToString() + FilePath + ((char)(34)).ToString();
                string toolname = string.Empty;
                toolname = (GetSoftwareInstalledPath("Uedit32.exe")); //"C:\Program Files\Adobe\Reader 8.0\Reader\AcroRd32.exe"
                if (toolname.Length == 0)
                {
                    return false;
                }
                if (System.IO.File.Exists(toolname) && System.IO.File.Exists(FilePath))
                {
                    ExecuteCommand(toolname, FilePath);
                    //Microsoft.VisualBasic.Interaction.Shell(toolname + " " + FilePath, Microsoft.VisualBasic.AppWinStyle.NormalFocus, false, -1);
                    //Dim r As New clsRunProcess(toolname, argsName, ProjectDet.pxeBasePath, "", False)
                    //r.ExecuteProcess()
                }
                else
                {
                    return false;
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool OpenFilesinNotePadPlusPlus(string FilePath)
        {
            try
            {
                string argsName = ((char)(34)).ToString() + FilePath + ((char)(34)).ToString();
                string toolname = string.Empty;
                toolname = (GetSoftwareInstalledPath("notepad++.exe")); //"C:\Program Files\Adobe\Reader 8.0\Reader\AcroRd32.exe"'notepad++.exe
                if (toolname.Length == 0)
                {
                    return false;
                }
                if (File.Exists(toolname) && File.Exists(FilePath))
                {
                    ExecuteCommand(toolname, FilePath);
                    //Microsoft.VisualBasic.Interaction.Shell(toolname + " " + FilePath, Microsoft.VisualBasic.AppWinStyle.MinimizedFocus, false, -1);
                    //Dim r As New clsRunProcess(toolname, argsName, ProjectDet.pxeBasePath, "", False)
                    //r.ExecuteProcess()
                }
                else
                {
                    return false;
                }
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool OpenFilesinEditors(string FilePath)
        {
            try
            {
                string argsName = ((char)(34)).ToString() + FilePath + ((char)(34)).ToString();
                string toolname = string.Empty;
                toolname = (GetSoftwareInstalledPath("Uedit32.exe")); //"C:\Program Files\Adobe\Reader 8.0\Reader\AcroRd32.exe"
                if (toolname.Length == 0)
                {
                    toolname = (GetSoftwareInstalledPath("notepad++.exe"));
                }
                if (toolname.Length == 0)
                {
                    toolname = @"C:\Windows\System32\notepad.exe";
                }
                if (System.IO.File.Exists(toolname) && System.IO.File.Exists(FilePath))
                {

                    clsCommonFunctions.ExecuteCommand(toolname, FilePath, false);
                    //Microsoft.VisualBasic.Shell(toolname & " " & FilePath, AppWinStyle.NormalFocus)
                    //Dim r As New clsRunProcess(toolname, argsName, ProjectDet.pxeBasePath, "", False)
                    //r.ExecuteProcess()
                }
                else
                {
                    return false;
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool OpenFileinDefault(string FilePath)
        {
            try
            {
                System.Diagnostics.ProcessStartInfo process = new System.Diagnostics.ProcessStartInfo();
                process.FileName = FilePath;
                System.Diagnostics.Process.Start(process);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static string GetSoftwareInstalledPath(string SoftwareName)
        {
            try
            {
                if (!(string.IsNullOrEmpty(SoftwareName)))
                {
                    string sRegistryPath = string.Empty;
                    if (SoftwareName.ToLower() == "java")
                    {
                        sRegistryPath = "Software\\JavaSoft\\Java Runtime Environment";
                    }
                    else
                    {
                        //sRegistryPath = "Software\MicroSoft\Windows\CurrentVersion\App Paths\"
                        sRegistryPath = "Software\\MicroSoft\\Windows\\CurrentVersion\\App Paths\\";
                    }

                    string sFilePath = string.Empty;

                    if (SoftwareName.ToString().Length == 0) //If exe name has not given then return false
                    {
                        return string.Empty;
                    }

                    if (SoftwareName.ToString().ToLower().EndsWith(".exe") == false) //If the extention is not ends with exe then return false
                    {
                        return string.Empty;
                    }
                    try
                    {
                        //If the software has not installed then it will throw an Null reference exeception
                        string SearchPath = sRegistryPath + SoftwareName;
                        sFilePath = (Microsoft.Win32.Registry.LocalMachine.OpenSubKey(SearchPath, false).GetValue("path").ToString());
                    }
                    catch
                    {
                        return string.Empty;
                    }

                    if (sFilePath.ToString().EndsWith("\\") == false)
                    {
                        sFilePath = sFilePath + "\\";
                    }

                    if (File.Exists(sFilePath + SoftwareName) == false)
                    {
                        return string.Empty;
                    }
                    else
                    {
                        //Process.Start(sFilePath & SoftwareName, sLogFilePath)
                        return sFilePath + SoftwareName;
                    }
                }
                else
                {
                    return string.Empty;
                }
            }
            catch
            {
                return string.Empty;
            }
        }

        public static bool fnIsMathTypeInstalled()
        {
            try
            {
                Microsoft.Win32.RegistryKey hklm = null;
                Microsoft.Win32.RegistryKey software = null;
                string[] subkeys = null;
                hklm = Microsoft.Win32.Registry.LocalMachine;
                software = hklm.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall");
                subkeys = software.GetSubKeyNames();
                bool Playerflag = false;

                foreach (string keyname in subkeys)
                {
                    if (keyname == ("DSMT6"))
                    {
                        Playerflag = true;
                        break;
                    }
                }

                return Playerflag;
            }
            catch
            {
                return false;
            }
        }

        public static bool fnIsCurrentVersionMathTypeInstalled()
        {
            try
            {
                Microsoft.Win32.RegistryKey hklm = null;
                Microsoft.Win32.RegistryKey software = null;
                string[] subkeys = null;
                hklm = Microsoft.Win32.Registry.LocalMachine;
                software = hklm.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\DSMT6");
                subkeys = software.GetValueNames();
                bool Playerflag = false;

                foreach (string keyname in subkeys)
                {
                    if (keyname == ("DisplayVersion"))
                    {
                        object sVersion = software.GetValue(keyname);
                        if (sVersion != null)
                        {
                            if (sVersion.ToString() == "6.8" || sVersion.ToString() == "6.9")
                            {
                                Playerflag = true;
                                break;
                            }
                        }
                    }
                }

                return Playerflag;
            }
            catch
            {
                return false;
            }
        }
        public static string textToBase64(string sAscii)
        {
            System.Text.ASCIIEncoding encoding = new System.Text.ASCIIEncoding();
            byte[] bytes = encoding.GetBytes(sAscii);
            return System.Convert.ToBase64String(bytes, 0, bytes.Length);
        }
        public static string base64ToText(string sbase64)
        {
            byte[] bytes = System.Convert.FromBase64String(sbase64);
            System.Text.ASCIIEncoding encoding = new System.Text.ASCIIEncoding();
            return encoding.GetString(bytes, 0, bytes.Length);
        }

        public static string fnCleanUpStringForRegexMatch(string sText)
        {
            string sSplChars = @"\.|\$|\^|\{|\}|\[|\]|\(|\||\)|\*|\+|\?|\\";
            return Regex.Replace(sText, sSplChars, eval, RegexOptions.IgnoreCase | RegexOptions.Singleline);
        }

        private static String eval(Match match)
        {
            return @"\" + match.Value;
        }

        //DBLibrary Start
        public static string GetISODateTimeForFileName(System.DateTime tempDate)
        {
            return tempDate.ToString("yyyy_MMM_dd_HH-mm-ss");
        }

        public static string GetISODateTime(System.DateTime tempDate)
        {
            return tempDate.ToString("yyyy-MM-dd HH:mm:ss");
        }

        public static string ToOurString(object tvalue)
        {
            if (tvalue != null)
            {
                return tvalue.ToString();
            }
            return string.Empty;
        }

        public static long ToLong(object tvalue)
        {
            if (tvalue != null)
            {
                long val = 0;
                if (long.TryParse(tvalue.ToString(), out val))
                {
                    return val;
                }
            }
            return 0;
        }

        public static int ToInt(object tvalue)
        {
            if (tvalue != null)
            {
                int nVal = 0;
                if (int.TryParse(tvalue.ToString(), out nVal))
                {
                    return nVal;
                }
            }
            return 0;
        }

        public static int ToIntRoundOff(object tvalue)
        {
            if (tvalue != null)
            {
                decimal dVal = 0;
                if (decimal.TryParse(tvalue.ToString(), out dVal))
                {
                    return decimal.ToInt32(decimal.Round(dVal));
                }
            }
            return 0;
        }


        public static double TODouble(Object tvalue)
        {
            double nReturnValue = 0;
            try
            {
                if (tvalue != null)
                {
                    if (tvalue.ToString() == "")
                        nReturnValue = 0;

                    //nReturnValue = Decimal.ToInt32(Decimal.Ceiling(decimal.Parse(tvalue.ToString())));
                    nReturnValue = Decimal.ToDouble(decimal.Parse(tvalue.ToString()));
                }
                else
                {
                    nReturnValue = 0;
                }
            }
            catch
            {
                nReturnValue = 0;
            }

            return nReturnValue;
        }




        /// <summary>
        /// write html content
        /// </summary>
        /// <param name="FilePath">file path</param>
        /// <param name="strContent">file content</param>        
        public static void SafeWriter(string FilePath, string strContent, System.Text.Encoding encoding = null)
        {
            if (File.Exists(FilePath))
            {
                File.Delete(FilePath);
                FileStream fs = new FileStream(FilePath, FileMode.Create, FileAccess.Write);//Save Current File                       
                StreamWriter s;

                if (encoding != null)
                    s = new StreamWriter(fs, encoding);
                else
                    s = new StreamWriter(fs);

                s.BaseStream.Seek(0, SeekOrigin.End);
                s.Write(strContent);
                s.Close();
                fs.Close();
            }
            else
            {

                FileStream fs = new FileStream(FilePath, FileMode.Create, FileAccess.Write);//Save Current File                       
                StreamWriter s = new StreamWriter(fs, System.Text.Encoding.Default);
                //StreamWriter s = new StreamWriter(fs);
                s.BaseStream.Seek(0, SeekOrigin.End);
                s.Write(strContent);
                s.Close();
                fs.Close();
            }
        }



        // This constant string is used as a "salt" value for the PasswordDeriveBytes function calls.
        // This size of the IV (in bytes) must = (keysize / 8).  Default keysize is 256, so the IV must be
        // 32 bytes long.  Using a 16 character string here gives us 32 bytes when converted to a byte array.
        private const string initVector = "r5dm5fgm24mfhfku";
        private const string passPhrase = "int3g6aspyga8e"; // email password encryption password

        // This constant is used to determine the keysize of the encryption algorithm.
        private const int keysize = 256;

        public static string encryptString(string plainText)
        {
            //if the plaintext  is empty or null string just return an empty string
            if (plainText == "" || plainText == null)
            {
                return "";
            }

            byte[] initVectorBytes = Encoding.UTF8.GetBytes(initVector);
            byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);
            PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, null);
            byte[] keyBytes = password.GetBytes(keysize / 8);
            RijndaelManaged symmetricKey = new RijndaelManaged();
            symmetricKey.Mode = CipherMode.CBC;
            ICryptoTransform encryptor = symmetricKey.CreateEncryptor(keyBytes, initVectorBytes);
            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write);
            cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
            cryptoStream.FlushFinalBlock();
            byte[] cipherTextBytes = memoryStream.ToArray();
            memoryStream.Close();
            cryptoStream.Close();
            return Convert.ToBase64String(cipherTextBytes);
        }

        public static string decryptString(string cipherText)
        {
            //if the ciphertext is empty or null string just return an empty string
            if (cipherText == "" || cipherText == null)
            {
                return "";
            }

            byte[] initVectorBytes = Encoding.ASCII.GetBytes(initVector);
            byte[] cipherTextBytes = Convert.FromBase64String(cipherText);
            PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, null);
            byte[] keyBytes = password.GetBytes(keysize / 8);
            RijndaelManaged symmetricKey = new RijndaelManaged();
            symmetricKey.Mode = CipherMode.CBC;
            ICryptoTransform decryptor = symmetricKey.CreateDecryptor(keyBytes, initVectorBytes);
            MemoryStream memoryStream = new MemoryStream(cipherTextBytes);
            CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);
            byte[] plainTextBytes = new byte[cipherTextBytes.Length];
            int decryptedByteCount = cryptoStream.Read(plainTextBytes, 0, plainTextBytes.Length);
            memoryStream.Close();
            cryptoStream.Close();
            return Encoding.UTF8.GetString(plainTextBytes, 0, decryptedByteCount);
        }

        public static string fnRemoveEndingLabelSplChars(string sLabelValue)
        {
            try
            {
                string[] strLabelEndIgnore = new string[] { ".", ",", ":", ";", "-" };
                if (strLabelEndIgnore.Any(sEach => sLabelValue.EndsWith(sEach)))
                {
                    return sLabelValue.Substring(0, sLabelValue.Length - 1);
                }
            }
            catch { }

            return sLabelValue;
        }

        public static string fnRemoveEndingSplChars(string sCitationValue)
        {
            try
            {
                string[] strSplChars = new string[] { ".", "&", "-", ",", ";" };
                if (strSplChars.Any(str => sCitationValue.EndsWith(str)))
                {
                    sCitationValue = sCitationValue.Substring(0, sCitationValue.Length - 1);
                    sCitationValue = fnRemoveEndingSplChars(sCitationValue);
                }

                return fnRemoveUnmatchedClosingBracket(sCitationValue);
            }
            catch { }

            return fnRemoveUnmatchedClosingBracket(sCitationValue);
        }

        public static string fnRemoveUnmatchedClosingBracket(string sCitationValue)
        {
            try
            {
                if (sCitationValue.EndsWith(")"))
                {
                    if (!sCitationValue.Contains("("))
                    {
                        sCitationValue = sCitationValue.Substring(0, sCitationValue.Length - 1);
                    }
                }

                if (sCitationValue.EndsWith("]"))
                {
                    if (!sCitationValue.Contains("["))
                    {
                        sCitationValue = sCitationValue.Substring(0, sCitationValue.Length - 1);
                    }
                }

                if (sCitationValue.Contains("("))
                {
                    if (!sCitationValue.EndsWith(")"))
                    {
                        sCitationValue = sCitationValue.Substring(0, sCitationValue.IndexOf('('));
                    }
                }

                if (sCitationValue.Contains("["))
                {
                    if (!sCitationValue.EndsWith("]"))
                    {
                        sCitationValue = sCitationValue.Substring(0, sCitationValue.IndexOf('['));
                    }
                }
                return sCitationValue;
            }
            catch { }
            return sCitationValue;
        }

        public static bool fnRemoveEndingSubAplhas(string sCitationValue, ref string sNewCitationValue)
        {
            try
            {
                if (String.IsNullOrEmpty(sCitationValue))
                {
                    return false;
                }

                if (Regex.IsMatch(sCitationValue, "[IXVCDM]{1,}", RegexOptions.IgnoreCase))
                    return false;       // Condition added by Dharani Req by Arbutharaj   Table IV - if IV donot have any bookmark then skip it ----- link should not generate for Table I                    

                string sEndingVal = sCitationValue.Substring(sCitationValue.Length - 1);
                sNewCitationValue = "";
                if (Regex.IsMatch(sEndingVal, @"\(|[a-z]|\)|\.", RegexOptions.IgnoreCase))
                {
                    sNewCitationValue = sCitationValue.Substring(0, sCitationValue.Length - 1);
                    return true;
                }
                return false;
            }
            catch { }
            return false;
        }


        /// <summary>
        /// Method to convert Letter to Arabic 
        /// </summary>
        public static string fnLettertoArabic(string sText, ref string sErrMsg)
        {
            try
            {
                switch (sText.ToLower())
                {
                    case "one":
                    case "first":
                        sText = "1";
                        break;

                    case "two":
                    case "second":
                        sText = "2";
                        break;

                    case "three":
                    case "third":
                        sText = "3";
                        break;

                    case "four":
                    case "fourth":
                        sText = "4";
                        break;

                    case "five":
                    case "fifth":
                        sText = "5";
                        break;

                    case "six":
                    case "sixth":
                        sText = "6";
                        break;

                    case "seven":
                    case "seventh":
                        sText = "7";
                        break;

                    case "eight":
                    case "eighth":
                        sText = "8";
                        break;

                    case "nine":
                    case "ninth":
                        sText = "9";
                        break;

                    case "ten":
                    case "tenth":
                        sText = "10";
                        break;

                    case "eleven":
                    case "eleventh":
                        sText = "11";
                        break;

                    case "twelve":
                    case "twelfth":
                        sText = "12";
                        break;

                    case "thirteen":
                    case "thirteenth":
                        sText = "13";
                        break;

                    case "fourteen":
                    case "fourteenth":
                        sText = "14";
                        break;

                    case "fifteen":
                    case "fifteenth":
                        sText = "15";
                        break;

                    case "sixteen":
                    case "sixteenth":
                        sText = "16";
                        break;

                    case "seventeen":
                    case "seventeenth":
                        sText = "17";
                        break;

                    case "eighteen":
                    case "eighteenth":
                        sText = "18";
                        break;

                    case "nineteen":
                    case "nineteenth":
                        sText = "19";
                        break;

                    case "twenty":
                    case "twentieth":
                        sText = "20";
                        break;
                }
            }
            catch (Exception ex)
            {
                sErrMsg = ex.Message;
            }
            return sText;
        }


        /// <summary>
        /// convert the chapter number to String.
        /// </summary>
        /// <param name="NumVal"></param>
        /// <returns></returns>
        public static string NumberToString(int NumVal)
        {
            string CitationStr = string.Empty;

            switch (NumVal)
            {
                case 1:
                    CitationStr = "first";
                    break;
                case 2:
                    CitationStr = "second";
                    break;
                case 3:
                    CitationStr = "third";
                    break;
                case 4:
                    CitationStr = "fourth";
                    break;
                case 5:
                    CitationStr = "fifth";
                    break;
                case 6:
                    CitationStr = "sixth";
                    break;
                case 7:
                    CitationStr = "seventh";
                    break;
                case 8:
                    CitationStr = "eigth";
                    break;
                case 9:
                    CitationStr = "ninth";
                    break;
                case 10:
                    CitationStr = "tenth";
                    break;
                case 11:
                    CitationStr = "eleventh";
                    break;
                case 12:
                    CitationStr = "twelth";
                    break;
                case 13:
                    CitationStr = "thirteenth";
                    break;
                case 14:
                    CitationStr = "fourteenth";
                    break;
                case 15:
                    CitationStr = "fifteenth";
                    break;
                case 16:
                    CitationStr = "sixteenth";
                    break;
                case 17:
                    CitationStr = "seventeenth";
                    break;
                case 18:
                    CitationStr = "eighteenth";
                    break;
                case 19:
                    CitationStr = "nineteenth";
                    break;
                case 20:
                    CitationStr = "twentieth";
                    break;
                case 21:
                    CitationStr = "twenty first";
                    break;
                case 22:
                    CitationStr = "twenty second";
                    break;
                case 23:
                    CitationStr = "twenty third";
                    break;
                case 24:
                    CitationStr = "twenty fourth";
                    break;
                case 25:
                    CitationStr = "twenty fifth";
                    break;
                case 26:
                    CitationStr = "twenty sixth";
                    break;
                case 27:
                    CitationStr = "twenty seventh";
                    break;
                case 28:
                    CitationStr = "twenty eighth";
                    break;
                case 29:
                    CitationStr = "twenty ninth";
                    break;
                case 30:
                    CitationStr = "thirtieth";
                    break;
                case 31:
                    CitationStr = "thirty first";
                    break;
                case 32:
                    CitationStr = "thirty second";
                    break;
                case 33:
                    CitationStr = "thirty third";
                    break;
                case 34:
                    CitationStr = "thirty fourth";
                    break;
                case 35:
                    CitationStr = "thirty fifth";
                    break;
                case 36:
                    CitationStr = "thirty sixth";
                    break;
                case 37:
                    CitationStr = "thirty seventh";
                    break;
                case 38:
                    CitationStr = "thirty eighth";
                    break;
                case 39:
                    CitationStr = "thirty ninth";
                    break;
                case 40:
                    CitationStr = "fortieth";
                    break;
                case 41:
                    CitationStr = "forty first";
                    break;
                case 42:
                    CitationStr = "forty  second";
                    break;
                case 43:
                    CitationStr = "forty  third";
                    break;
                case 44:
                    CitationStr = "forty  fourth";
                    break;
                case 45:
                    CitationStr = "forty  fifth";
                    break;
                case 46:
                    CitationStr = "forty  sixth";
                    break;
                case 47:
                    CitationStr = "forty  seventh";
                    break;
                case 48:
                    CitationStr = "forty  eighth";
                    break;
                case 49:
                    CitationStr = "forty  ninth";
                    break;
                case 50:
                    CitationStr = "fiftieth";
                    break;
                    //default:
                    //    break;
            }
            return CitationStr;
        }

        public static int ConvertRomanNumtoInt(string strRomanValue)
        {

            Dictionary<string, int> RomanNumbers = new Dictionary<string, int>();
            RomanNumbers.Add("m", 1000);
            RomanNumbers.Add("cm", 900);
            RomanNumbers.Add("d", 500);
            RomanNumbers.Add("cd", 400);
            RomanNumbers.Add("c", 100);
            RomanNumbers.Add("xc", 90);
            RomanNumbers.Add("l", 50);
            RomanNumbers.Add("xl", 40);
            RomanNumbers.Add("x", 10);
            RomanNumbers.Add("ix", 9);
            RomanNumbers.Add("v", 5);
            RomanNumbers.Add("iv", 4);
            RomanNumbers.Add("i", 1);

            int retVal = 0;
            foreach (KeyValuePair<string, int> pair in RomanNumbers)
            {
                while (strRomanValue.IndexOf(pair.Key.ToString()) == 0)
                {
                    retVal += int.Parse(pair.Value.ToString());
                    strRomanValue = strRomanValue.Substring(pair.Key.ToString().Length);
                }
            }
            return retVal;
        }

        public static int ParseWordToInt(string number)
        {
            string[] words = number.ToLower().Split(new char[] { ' ', '-', ',' }, StringSplitOptions.RemoveEmptyEntries);
            string[] ones = { "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };
            string[] teens = { "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen" };
            string[] tens = { "ten", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety" };
            Dictionary<string, int> modifiers = new Dictionary<string, int>() {
        {"billion", 1000000000},
        {"million", 1000000},
        {"thousand", 1000},
        {"hundred", 100}
    };

            if (number == "eleventy billion")
                return int.MaxValue; // 110,000,000,000 is out of range for an int!

            int result = 0;
            int currentResult = 0;
            int lastModifier = 1;

            foreach (string word in words)
            {
                if (modifiers.ContainsKey(word))
                {
                    lastModifier *= modifiers[word];
                }
                else
                {
                    int n;

                    if (lastModifier > 1)
                    {
                        result += currentResult * lastModifier;
                        lastModifier = 1;
                        currentResult = 0;
                    }

                    if ((n = Array.IndexOf(ones, word) + 1) > 0)
                    {
                        currentResult += n;
                    }
                    else if ((n = Array.IndexOf(teens, word) + 1) > 0)
                    {
                        currentResult += n + 10;
                    }
                    else if ((n = Array.IndexOf(tens, word) + 1) > 0)
                    {
                        currentResult += n * 10;
                    }
                    else if (word != "and")
                    {
                        return 0;
                    }
                }
            }

            return result + currentResult * lastModifier;
        }

        //DB End

        #region Auto Message close

        [System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]
        static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
        [System.Runtime.InteropServices.DllImport("user32.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto)]
        static extern IntPtr PostMessage(IntPtr hWnd, UInt32 Msg, IntPtr wParam, IntPtr lParam);

        public static void AutoHideMessageBox(string _Capt, string Statement)
        {
            try
            {
                const int WM_CLOSE = 0x0010;
                IntPtr mbWnd = FindWindow(null, _Capt); // "Microsoft Word");
                PostMessage(mbWnd, WM_CLOSE, IntPtr.Zero, IntPtr.Zero);
            }
            catch { }
        }

        #endregion

        public static string getAplhaFromNumber(int nNum)
        {
            if (nNum < 1) return string.Empty;

            char[] arrVals = new char[] { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };

            int nTimes = nNum / 26;
            int nNewNum = nNum % 26;
            StringBuilder sText = new StringBuilder();
            if (nNewNum == 0)
            {
                nTimes--;
                nNewNum = 26;
            }

            sText.Append(arrVals[nNewNum - 1]);
            while (nTimes > 0)
            {
                sText.Append(arrVals[nNewNum - 1]);
                nTimes--;
            }

            return sText.ToString();
        }

        public static string getSymbolFromNumber(int nNum)
        {
            if (nNum < 1) return string.Empty;
            char[] arrVals = new char[] { '*', '†', '‡', '§' };

            int nTimes = nNum / 4;
            int nNewNum = nNum % 4;
            StringBuilder sText = new StringBuilder();
            if (nNewNum == 0)
            {
                nTimes--;
                nNewNum = 4;
            }

            sText.Append(arrVals[nNewNum - 1]);
            while (nTimes > 0)
            {
                sText.Append(arrVals[nNewNum - 1]);
                nTimes--;
            }

            return sText.ToString();
        }


        public static string NumberToWords(int number)
        {
            string words = "";
            try
            {
                if (number == 0)
                    return "Zero";

                if (number < 0)
                    return "Minus " + NumberToWords(Math.Abs(number));

                if ((number / 1000000) > 0)
                {
                    words += NumberToWords(number / 1000000) + " Million ";
                    number %= 1000000;
                }

                if ((number / 1000) > 0)
                {
                    words += NumberToWords(number / 1000) + " Thousand ";
                    number %= 1000;
                }

                if ((number / 100) > 0)
                {
                    words += NumberToWords(number / 100) + " Hundred ";
                    number %= 100;
                }

                if (number > 0)
                {
                    if (words != "")
                        words += "and ";

                    var unitsMap = new[] { "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen" };
                    var tensMap = new[] { "zero", "Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety" };

                    if (number < 20)
                        words += unitsMap[number];
                    else
                    {
                        words += tensMap[number / 10];
                        if ((number % 10) > 0)
                            words += "-" + unitsMap[number % 10];
                    }
                }
            }
            catch
            {
                return string.Empty;
            }
            return words;
        }

        public static string ToOrdinal(string number)
        {
            if (String.IsNullOrEmpty(number)) return number;
            var dict = new Dictionary<string, string>();
            dict.Add("zero", "zeroth");
            dict.Add("nought", "noughth");
            dict.Add("one", "first");
            dict.Add("two", "second");
            dict.Add("three", "third");
            dict.Add("four", "fourth");
            dict.Add("five", "fifth");
            dict.Add("six", "sixth");
            dict.Add("seven", "seventh");
            dict.Add("eight", "eighth");
            dict.Add("nine", "ninth");
            dict.Add("ten", "tenth");
            dict.Add("eleven", "eleventh");
            dict.Add("twelve", "twelfth");
            dict.Add("thirteen", "thirteenth");
            dict.Add("fourteen", "fourteenth");
            dict.Add("fifteen", "fifteenth");
            dict.Add("sixteen", "sixteenth");
            dict.Add("seventeen", "seventeenth");
            dict.Add("eighteen", "eighteenth");
            dict.Add("nineteen", "nineteenth");
            dict.Add("twenty", "twentieth");
            dict.Add("thirty", "thirtieth");
            dict.Add("forty", "fortieth");
            dict.Add("fifty", "fiftieth");
            dict.Add("sixty", "sixtieth");
            dict.Add("seventy", "seventieth");
            dict.Add("eighty", "eightieth");
            dict.Add("ninety", "ninetieth");
            dict.Add("hundred", "hundredth");
            dict.Add("thousand", "thousandth");
            dict.Add("million", "millionth");
            dict.Add("billion", "billionth");
            dict.Add("trillion", "trillionth");
            dict.Add("quadrillion", "quadrillionth");
            dict.Add("quintillion", "quintillionth");
            // rough check whether it's a valid number
            string temp = number.ToLower().Trim().Replace(" and ", " ");
            string[] words = temp.Split(new char[] { ' ', '-' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string word in words)
            {
                if (!dict.ContainsKey(word)) return number;
            }
            // extract last word
            number = number.TrimEnd().TrimEnd('-');
            int index = number.LastIndexOfAny(new char[] { ' ', '-' });
            string last = number.Substring(index + 1);
            // make replacement and maintain original capitalization
            if (last == last.ToLower())
            {
                last = dict[last];
            }
            else if (last == last.ToUpper())
            {
                last = dict[last.ToLower()].ToUpper();
            }
            else
            {
                last = last.ToLower();
                last = Char.ToUpper(dict[last][0]) + dict[last].Substring(1);
            }
            return number.Substring(0, index + 1) + last;
        }

        public static string ReplaceCharORWords(string OriginalContent, string ReplaceCharORWord = "", List<string> SpecialCharList = null)
        {
            try
            {
                if (SpecialCharList == null || SpecialCharList.Count <= 0)
                    SpecialCharList = new string[] { ",", "/", "\\", "(", ")", "-", ";", ":" }.ToList();
                SpecialCharList.ForEach(s => OriginalContent = OriginalContent.Replace(s, ReplaceCharORWord));
            }
            catch { }
            return OriginalContent;
        }

        /// <summary>
        /// This method will find the string is having All characters as upper case.
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static bool IsAllUpper(string input)
        {
            try
            {
                bool bIsAtleastOneLetterCapsFound = false;
                bool bIsSmallFound = false;
                for (int i = 0; i < input.Length; i++)
                {
                    if (!Char.IsLetter(input[i]))
                        continue;

                    if (Char.IsUpper(input[i]))
                        bIsAtleastOneLetterCapsFound = true;
                    else
                        bIsSmallFound = true;

                    if (!bIsAtleastOneLetterCapsFound)
                        return false;
                }

                if (bIsAtleastOneLetterCapsFound)
                {
                    if (bIsSmallFound)
                        return false;
                    else
                        return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {

            }

            return false;
        }

        /// <summary>
        ///File Backup
        /// </summary>


        public static void FnWriteFile(string Content, string FileName, FileType Type = FileType.None)
        {
            try
            {
                bool IsExit = false;

                string info = Content;

                switch (Type)
                {
                    case FileType.None:
                    case FileType.TEXT:
                        FileName = string.Format("{0}.txt", FileName);
                        break;
                    case FileType.XML:
                        FileName = string.Format("{0}.xml", FileName);
                        break;
                    case FileType.INI:
                        FileName = string.Format("{0}.ini", FileName);
                        break;
                }

                if (File.Exists(FileName))
                {
                    File.Delete(FileName);
                    using (File.Create(FileName)) { }
                    IsExit = true;
                }
                else
                {
                    using (File.Create(FileName)) { }
                    IsExit = true;
                }

                if (IsExit)
                {
                    File.WriteAllText(FileName, info);
                }
            }
            catch { }
        }

        public enum FileType
        {
            None,
            TEXT,
            XML,
            INI
        }





    }



}

