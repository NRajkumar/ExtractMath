﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.Xml;

namespace MathToText
{
    public static class clsMathMLCleanup
    {
        public static StringBuilder sbOutpuVal;
        public static string sMNTagName = string.Empty;

        public static string DoMathMLCleanup(string sActualMathContent, ref string sErrMsg)
        {
            try
            {
                sActualMathContent.Trim();
                sActualMathContent = Regex.Replace(sActualMathContent, "<m:annotation(?: [^><]+)?>((?!</?m:annotation[ >]).)*</m:annotation>", "", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                sActualMathContent = Regex.Replace(sActualMathContent, "<!--(?:(?!-->).)*-->", "", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                sActualMathContent = Regex.Replace(sActualMathContent, "mml:", "m:", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                sActualMathContent = Regex.Replace(sActualMathContent, "([ ]*[\r\n]+[ ]*)", "", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                sActualMathContent = Regex.Replace(sActualMathContent, @"(<((?:m(?:ml)?\:)?mn)[^<>]*>)((?:(?!(?:<(?:(?:m(?:ml)?\:)?mn)[^<>]*>)).)+)</\2>", ProcessMNTag, RegexOptions.IgnoreCase | RegexOptions.Singleline).Trim();
                sActualMathContent = Regex.Replace(sActualMathContent, @"(?:<((?:m(?:ml)?\:)?mn)[^<>]*></\1>)", "", RegexOptions.IgnoreCase | RegexOptions.Singleline).Trim();

                sActualMathContent = Regex.Replace(sActualMathContent, @"<((?:m(?:ml)?\:)?(?:mo|mtext))>(&#x(?:00A0|2002|2003);)(</\1>)(<((?:m(?:ml)?\:)?(?:mo))>(?:(?!</?\5>).)+</\5>)<((?:m(?:ml)?\:)?(?:mo|mtext))>(&#x(?:00A0|2002|2003);)(</\6>)", "$4", RegexOptions.IgnoreCase | RegexOptions.Singleline).Trim();
                sActualMathContent = Regex.Replace(sActualMathContent, @"<((?:m(?:ml)?\:)?(?:mo))>&#x00A0;</\1>(?=<(?:(?:m(?:ml)?\:)?(?:mo))>)", "", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                sActualMathContent = Regex.Replace(sActualMathContent, @"<((?:m(?:ml)?\:)?(?:mo))>&#x00A0;</\1>(?=<(?:(?:m(?:ml)?\:)?(?:mi))>)", "<$1>&#x0020;</$1>", RegexOptions.IgnoreCase | RegexOptions.Singleline);

                sActualMathContent = Regex.Replace(sActualMathContent, @"(<((?:m(?:ml)?\:)?mtext)[^<>]*>)((?:(?!(?:<(?:(?:m(?:ml)?\:)?mtext)[^<>]*>)).)+)</\2>", ProcessNBSP, RegexOptions.IgnoreCase | RegexOptions.Singleline);
                sActualMathContent = Regex.Replace(sActualMathContent, @"(?<=</(?:(?:m(?:ml)?\:)?(?:mi))>)<((?:m(?:ml)?\:)?(?:mo))>&#x00A0;</\1>", ProcessNBSP, RegexOptions.IgnoreCase | RegexOptions.Singleline);

                sActualMathContent = Regex.Replace(sActualMathContent, @"<((m(?:ml)?\:)?(?:mo))>&#x00A0;</\1>", "<$2mtext>&#x0020;</$2mtext>", RegexOptions.IgnoreCase | RegexOptions.Singleline);
            }
            catch (Exception ex)
            {

            }
            return XMLPrettyViewProcess(sActualMathContent);
        }

        private static string ProcessNBSP(Match matchMN)
        {
            string sOutpuString = matchMN.Value.ToString();

            try
            {
                sOutpuString = Regex.Replace(sOutpuString, "&#x00A0;", "&#x0020;", RegexOptions.IgnoreCase | RegexOptions.Singleline);
            }
            catch (Exception ex)
            {

            }
            return sOutpuString;
        }


        private static string ProcessMNTag(Match matchMN)
        {
            string sOutpuString = string.Empty;
            sbOutpuVal = new StringBuilder();
            try
            {
                string sMNOpenTagFull = matchMN.Groups[1].Value;
                sMNTagName = matchMN.Groups[2].Value;
                string sMNInnerContent = matchMN.Groups[3].Value;
                sOutpuString = string.Format("{0}", SplitMNTags(matchMN.Groups[3]));
            }
            catch (Exception ex)
            {

            }
            return sOutpuString;
        }

        private static string SplitMNTags(Group matchVal)
        {
            try
            {
                if (Regex.IsMatch(matchVal.Value, "^([^<>]+)(.*)$", RegexOptions.IgnoreCase))
                {
                    Match myMacth1 = Regex.Match(matchVal.Value, "^([^<>]+)(.*)$", RegexOptions.IgnoreCase);
                    sbOutpuVal.Append(string.Format("<{0}>{1}</{0}>", sMNTagName, myMacth1.Groups[1].Value));
                    matchVal = myMacth1.Groups[2];
                    SplitMNTags(matchVal);
                }
                else if (Regex.IsMatch(matchVal.Value, @"^(<((?:m(?:ml)?\:)?[a-z]+)[^<>]*>[^<>]*</\2>)(.*)$", RegexOptions.IgnoreCase))
                {
                    Match myMacth1 = Regex.Match(matchVal.Value, @"^(<((?:m(?:ml)?\:)?[a-z]+)[^<>]*>[^<>]*</\2>)(.*)$", RegexOptions.IgnoreCase);
                    sbOutpuVal.Append(string.Format("{0}", myMacth1.Groups[1].Value));
                    matchVal = myMacth1.Groups[3];
                    SplitMNTags(matchVal);
                }
            }
            catch (Exception ex)
            {

            }
            return sbOutpuVal.ToString();
        }

        private static string XMLPrettyViewProcess(string sOutputMathML)
        {
            try
            {
                string sMathFullOpenTag = string.Empty;
                string sMathTagName = string.Empty;

                if (Regex.IsMatch(sOutputMathML, "(<((?:m(?:ml)?\\:)math)[^<>]*>)", RegexOptions.IgnoreCase | RegexOptions.Singleline))
                {
                    Match MyMatch1 = Regex.Match(sOutputMathML, @"(<((?:m(?:ml)?\:)math)[^<>]*>)", RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    sMathFullOpenTag = MyMatch1.Groups[1].Value;
                    sMathTagName = MyMatch1.Groups[2].Value;

                    sOutputMathML = Regex.Replace(sOutputMathML, sMathFullOpenTag, string.Format("<{0} xmlns:m='http://www.w3.org/1998/Math/MathML' xmlns:mml='http://www.w3.org/1998/Math/MathML'>", sMathTagName), RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    sOutputMathML = Regex.Replace(sOutputMathML, "&", "&amp;");
                    sOutputMathML = PrintXML(sOutputMathML);
                    sOutputMathML = Regex.Replace(sOutputMathML, "&amp;", "&");

                    if (Regex.IsMatch(sOutputMathML, string.Format(@"<{0} xmlns:m=[""']http://www.w3.org/1998/Math/MathML['""] xmlns:mml=[""']http://www.w3.org/1998/Math/MathML[""']>", sMathTagName), RegexOptions.IgnoreCase | RegexOptions.Singleline))
                    {
                        sOutputMathML = Regex.Replace(sOutputMathML, string.Format(@"<{0} xmlns:m=[""']http://www.w3.org/1998/Math/MathML['""] xmlns:mml=[""']http://www.w3.org/1998/Math/MathML[""']>", sMathTagName), sMathFullOpenTag, RegexOptions.IgnoreCase | RegexOptions.Singleline);
                    }
                }
                else
                {
                    return sOutputMathML;
                }
            }
            catch (Exception ex)
            {

                return sOutputMathML;
            }
            return sOutputMathML;
        }

        private static String PrintXML(String XML)
        {
            String Result = "";

            MemoryStream mStream = new MemoryStream();
            XmlTextWriter writer = new XmlTextWriter(mStream, Encoding.Unicode);
            XmlDocument document = new XmlDocument();

            XmlNamespaceManager nsmgr = new XmlNamespaceManager(document.NameTable);
            nsmgr.AddNamespace("m", "http://www.w3.org/1998/Math/MathML");
            nsmgr.AddNamespace("mml", "http://www.w3.org/1998/Math/MathML");

            try
            {
                // Load the XmlDocument with the XML.
                document.LoadXml(XML);


                writer.Formatting = Formatting.Indented;

                // Write the XML into a formatting XmlTextWriter
                document.WriteContentTo(writer);
                writer.Flush();
                mStream.Flush();

                // Have to rewind the MemoryStream in order to read
                // its contents.
                mStream.Position = 0;

                // Read MemoryStream contents into a StreamReader.
                StreamReader sReader = new StreamReader(mStream);

                // Extract the text from the StreamReader.
                String FormattedXML = sReader.ReadToEnd();

                Result = FormattedXML;
            }
            catch (XmlException ex)
            {

            }

            mStream.Close();
            writer.Close();

            return Result;
        }

    }
}
