﻿using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using Ovml = DocumentFormat.OpenXml.Vml.Office;
using V = DocumentFormat.OpenXml.Vml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConvertEquations;
using MTSDKDN;
using System.Text.RegularExpressions;

namespace MathToText
{
    class Program
    {
        static void Main(string[] args)
        {
            string strDoc = @"C:\Users\menaka.s\Desktop\math_Images\math.docx";
                       string serrror = string.Empty;

            MathToText.MathtoText.doprocess(strDoc, MathtoText.OutPutType.Tex, ref serrror);
        }

    }
}
